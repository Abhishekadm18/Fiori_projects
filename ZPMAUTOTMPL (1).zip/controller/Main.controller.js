sap.ui.define(["sap/ui/core/mvc/Controller"], function (n) {
	"use strict";
	return n.extend("com.ZpmAutoTmpl.ZPMAutoTmpl.controller.Main", {
		onInit: function () {}
	})
});