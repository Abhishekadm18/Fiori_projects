sap.ui.define([
	"com/ZpmAutoTmpl/ZPMAutoTmpl/test/unit/controller/Main.controller"
], function () {
	"use strict";
});